package com.example.inridechat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InRideChatApplicationTests {

	@Test
	void contextLoads() {
	}

}
