package com.example.inridechat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InRideChatApplication {

	public static void main(String[] args) {
		SpringApplication.run(InRideChatApplication.class, args);
	}

}
